package com.security.template.model;

public enum TokenType {

    BEARER
}
